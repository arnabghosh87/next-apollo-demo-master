var casual = require('casual');

const {
  graphql,
  GraphQLSchema,
  GraphQLObjectType,
  GraphQLString,
  GraphQLList,
  GraphQLInt
} = require('graphql')
//const faker = require('faker');

//const userData = require("./data.json");

casual.define('user',function(){
  return {
    id:casual.uuid,
    email:casual.email,
    phoneNumber:casual.phone,
    name:casual.name,
    address:casual.address
  }
})

const userData = [];
for(i=0;i<2000;i++){
  //console.log(casual.user);
  userData.push(casual.user);
}
//const userData = casual.user;

//console.log(userData);

const UserType = new GraphQLObjectType({
  name:"User",
  fields: () => ({
    id:{type:GraphQLString},
    name:{type:GraphQLString},
    email:{type:GraphQLString},
    address:{type:GraphQLString},
    phoneNumber:{type:GraphQLString}
  })
})

module.exports = new GraphQLSchema({
  query: new GraphQLObjectType({
    name: 'RootQueryType',
    fields: {
      gelAllUsers:{
        type:new GraphQLList(UserType),
        args:{ first: { type:new GraphQLList(GraphQLInt)},
                after:{type:new GraphQLList(GraphQLInt)}
        },
        resolve(parent,args){
          //console.log(args);
          const modifiedUserData =  userData.filter((element, index) => {
            return index > args.after && index < args.after + args.first
          });
          return modifiedUserData;
        }
      },
      count:{
        type: GraphQLInt,
        resolve(parent,args){
          return userData.length
        }
      },
      nextIndex:{
        type: GraphQLInt,
        args:{ first: { type:new GraphQLList(GraphQLInt)},
                after:{type:new GraphQLList(GraphQLInt)}
        },
        resolve(parent,args){
          return parseInt(args.after) + parseInt(args.first);
        }
      }
    }
  })
})
