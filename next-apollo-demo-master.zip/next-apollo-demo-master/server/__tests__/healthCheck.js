const  graphql  = require('graphql');
const schema = require('../schema') ;



it('should be null when user is not logged in', async () => {
  //language=GraphQL
  const query = `
    query Q {
      viewer {
        me {
          name
        }
      }
    }
  `;

  const rootValue = {};
  
  const result = await graphql(schema, query, rootValue);
  const { data } = result;

  expect(data.viewer.me).toBe(null);
});

it('should return the current user when user is logged in', async () => {
  const user = {
    "id": "938a383a-e5a4-4627-bd9d-42e2ffe2f9f7",
    "name": "Ms. Humberto Bauch",
    "email": "Bruce.Adams@Hagenes.us",
    "phoneNumber": "157-427-8399",
    "address": "454 Malika Skyway Apt. 980\nEast Cletusberg, CO 78230"
  };
  
  const query = `
    query  {
        gelAllUsers(first:20,after:0) {
            id,
            name,
            email,
            phoneNumber,
            address
          }
      }
    }
  `;

  const rootValue = {};
  //const context = getContext({ user });

  const result = await graphql(schema, query, rootValue, user);
  const { data } = result;

  expect(data.gelAllUsers.name).toBe(user.name);
});