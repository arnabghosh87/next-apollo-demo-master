const express = require('express')
//const bodyParser = require('body-parser')
const cors = require('cors')
//const { graphqlExpress, graphiqlExpress,graphiqlConnect } = require('apollo-server-express')
const graphql = require('graphql');
const {graphqlHTTP} = require("express-graphql");
const myGraphQLSchema = require('./schema')

const app = express();

// to access graphql API from the client side
app.use(cors())
// bodyParser is needed just for POST.
app.use('/graphql', graphqlHTTP({
  schema:myGraphQLSchema,
  graphiql:true
}))

const port = process.env.PORT || 5000
app.listen(port, (err) => {
  if (err) throw err
  console.log(`Graphql Server started on: http://localhost:${port}`)
})
