import { gql } from '@apollo/client';

export const GET_USERS = gql`
query {
    gelAllUsers {
      name,
      email,
      phoneNumber,
      address
    }
  }
`