import { gql } from "@apollo/client";
import React, { useState } from "react";
import { ApolloClient, InMemoryCache } from "@apollo/client";
import Card from "../components/Card.js";


export default function Home({ characters }) {

  const [hasMore, setHasMore] = useState(true);
  const [address,setAddress] = useState(characters);
  const[nextIndex,setNextIndex] = useState(20);
  const[isLoading,setIsLoading] = useState(false);

  const client = new ApolloClient({
    uri: "http://localhost:5000/graphql",
    cache: new InMemoryCache(),
  });
  
   const getMorePost = async () => {
    setIsLoading(true);
    const { data } = await client.query({
      query: gql`
      query {
          gelAllUsers(first:20,after:${nextIndex}){
            id,
            name,
            email,
            phoneNumber,
            address
          },
          count,
          nextIndex(first:20,after:${nextIndex})
        }
      `,
    });
    setAddress(address.concat(data.gelAllUsers));
    setNextIndex(data.nextIndex);
    setIsLoading(false);
    if(data.nextIndex >= data.count){
      setHasMore(false);
    }
  };

  return (
    <div className="container">
      <header>
        <h1 className="text-center m-5">GraphQL Assignment</h1>
      </header>
      <div>
      <>
        <div className="row row-cols-auto justify-content-md-center">
        {address.map((data) => (
          <div key={data.id} className="col-lg-4 col-12 col-sm-6 mt-2">
            <Card character={data} key={data.id} />
          </div>
        ))}
      </div>
      <div className="mb-2 d-flex justify-content-center mt-2">
        <button onClick={getMorePost} className="btn btn-primary">
          {isLoading ? 'Loading...' : 'Load More'}
        </button>
        </div>
      
      <style jsx>
        {`
          .back {
            padding: 10px;
            background-color: dodgerblue;
            color: white;
            margin: 10px;
          }
        `}
      </style>
    </>
      </div>
    </div>
  );
}

export async function getStaticProps() {

  
  const client = new ApolloClient({
    uri: "http://localhost:5000/graphql",
    cache: new InMemoryCache(),
  });
  const { data } = await client.query({
    query: gql`
    query {
        gelAllUsers(first:20,after:0){
          id,
          name,
          email,
          phoneNumber,
          address
        }
      }
    `,
  });

  return {
    props: {
      characters: data.gelAllUsers,
    },
  };
}