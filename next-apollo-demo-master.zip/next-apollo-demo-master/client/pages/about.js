import Link from 'next/link'

export default () => (
  <div>
    About Page
    <br/><br/>
    <Link href="/"><a>Go Back</a></Link>
  </div>
)
