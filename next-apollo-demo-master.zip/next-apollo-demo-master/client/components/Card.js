const Card = ({ character }) => {
    return (
        <div className="card border-info h-100">
          <div className="card-body">
            <h5 className="card-title, mb-0 ">{character.name}</h5>
            <h6 className="card-subtitle text-muted mt-2">Address</h6>
            <p className="card-text">
              {character.address}
            </p>
            <h6 className="card-subtitle text-muted">Phone Number</h6>
            <p className="card-text">{character.phoneNumber}</p>
            <h6 className="card-subtitle text-muted">Email</h6>
            <p className="card-text">{character.email}</p>
          </div>
        </div>
    );
  };
  
  export default Card;